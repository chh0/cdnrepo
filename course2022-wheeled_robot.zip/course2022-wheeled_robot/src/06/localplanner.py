from re import X
import numpy as np
import math

class DWA:
    def heading(self, dx, dy, list, vw):
        theta = list[2] + vw
        v_x = math.cos(theta)
        v_y = math.sin(theta)
        return (dx*v_x + dy*v_y)/((dx*dx + dy*dy)**0.5)

    def dist(self, list, planning_obs, vx, vw, pre_t, obs_radius):
        points = []
        x = list[0]
        y = list[1]
        theta = list[2]
        num = 10
        dt = pre_t/num
        for i in range(num):
            x = x + vx*math.cos(theta)*dt
            y = y + vx*math.sin(theta)*dt
            theta = theta + vw*dt
            points.append([x, y])
            dis = np.hypot(planning_obs[:,0]-x, planning_obs[:,1]-y)
            if len(dis)>0 and min(dis) < obs_radius:
                # print(dis)
                return 1
        return 0

    def plan(self, list, dwaconfig, midpos, planning_obs):

        dx = midpos[0] - list[0]
        dy = midpos[1] - list[1]

        a = 1
        b = -5000
        c = 1

        vmax_config = dwaconfig.max_speed
        vmin_config = dwaconfig.min_speed
        amax = dwaconfig.max_accel

        wmax_config = dwaconfig.max_yawrate
        bmax = dwaconfig.max_accel

        vl = list[3] - amax*dwaconfig.dt
        vh = list[3] + amax*dwaconfig.dt
        wl = list[4] - bmax*dwaconfig.dt
        wh = list[4] + bmax*dwaconfig.dt

        vmax = min(vmax_config, vh)
        vmin = max(vmin_config, vl)
        wmax = min(wmax_config, wh)
        wmin = max(-wmax_config, wl)



        posibility = []
        num = 50
        for i in range(num):
            for j in range(num):
                posibility.append([vmin+i*(vmax-vmin)/num, wmin+j*(wmax-wmin)/num])

        marks = []
        for i in range(len(posibility)):
            mark = a*self.heading(dx, dy, list, posibility[i][1]) + b*self.dist(list, planning_obs, posibility[i][0], posibility[i][1], dwaconfig.predict_time, dwaconfig.obs_radius) + c*posibility[i][0]/vmax_config
            marks.append(mark)
            pass

        max_mark = max(marks)
        index = marks.index(max_mark)

        vx = posibility[index][0]
        vw = posibility[index][1]
        return vx, vw
    pass

# self.vx,self.vw = self.vplanner.plan([self.x,self.y,self.theta,self.vx,self.vw],self.dwaconfig,midpos,self.planning_obs)

# class DWAConfig:
#     robot_radius = 0.25
#     def __init__(self,obs_radius):
#         self.obs_radius = obs_radius
#         self.dt = 0.1  # [s] Time tick for motion prediction

#         self.max_speed = 1.0  # [m/s]
#         self.min_speed = -0.5  # [m/s]
#         self.max_accel = 1  # [m/ss]
#         self.v_reso = self.max_accel*self.dt/10.0  # [m/s]

#         self.max_yawrate = 100.0 * math.pi / 180.0  # [rad/s]
#         self.max_dyawrate = 100.0 * math.pi / 180.0  # [rad/ss]
#         self.yawrate_reso = self.max_dyawrate*self.dt/10.0  # [rad/s]

        
#         self.predict_time = 2  # [s]

#         self.to_goal_cost_gain = 1.0
#         self.speed_cost_gain = 0.1
#         self.obstacle_cost_gain = 1.0

#         self.tracking_dist = self.predict_time*self.max_speed
#         self.arrive_dist = 0.1

if __name__ == "__main__":
    pass